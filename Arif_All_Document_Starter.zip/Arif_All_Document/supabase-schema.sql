-- Run this entire script in Supabase Dashboard > SQL Editor.
-- Creates a private bucket, per-user document records, and strict ownership policies.

create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  storage_path text not null unique,
  file_name text not null,
  mime_type text not null default 'application/octet-stream',
  size_bytes bigint not null default 0,
  created_at timestamptz not null default now()
);

alter table public.documents enable row level security;

drop policy if exists "Users can read own documents" on public.documents;
create policy "Users can read own documents"
on public.documents for select to authenticated
using (auth.uid() = owner_id);

drop policy if exists "Users can add own documents" on public.documents;
create policy "Users can add own documents"
on public.documents for insert to authenticated
with check (auth.uid() = owner_id);

drop policy if exists "Users can delete own documents" on public.documents;
create policy "Users can delete own documents"
on public.documents for delete to authenticated
using (auth.uid() = owner_id);

insert into storage.buckets (id, name, public, file_size_limit)
values ('user-documents', 'user-documents', false, 52428800)
on conflict (id) do update set public = false, file_size_limit = 52428800;

drop policy if exists "Users can upload to own folder" on storage.objects;
create policy "Users can upload to own folder"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'user-documents'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "Users can read own folder" on storage.objects;
create policy "Users can read own folder"
on storage.objects for select to authenticated
using (
  bucket_id = 'user-documents'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "Users can delete from own folder" on storage.objects;
create policy "Users can delete from own folder"
on storage.objects for delete to authenticated
using (
  bucket_id = 'user-documents'
  and (storage.foldername(name))[1] = auth.uid()::text
);
