// 1) Paste your Supabase Project URL and anon/public key below.
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY";
const BUCKET = "user-documents";
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50 MB

const configured = SUPABASE_URL.startsWith("https://") &&
  !SUPABASE_URL.includes("PASTE_") && !SUPABASE_ANON_KEY.includes("PASTE_");
const client = configured ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

const $ = (id) => document.getElementById(id);
let authMode = "login";
let currentFile = null;

function message(id, text, error=false) {
  const el = $(id); el.textContent = text; el.classList.toggle("error", error);
}
function setMode(mode) {
  authMode = mode;
  $("loginTab").classList.toggle("active", mode === "login");
  $("signupTab").classList.toggle("active", mode === "signup");
  $("authTitle").textContent = mode === "login" ? "Welcome back" : "Create your account";
  $("authSubmit").textContent = mode === "login" ? "Login" : "Create account";
  $("forgotBtn").hidden = mode !== "login";
  $("password").autocomplete = mode === "login" ? "current-password" : "new-password";
  message("authMessage", "");
}
function showApp(user) {
  $("authPanel").hidden = true; $("appPanel").hidden = false;
  $("userEmail").textContent = user.email || "Signed in";
  loadFiles();
}
function showAuth() { $("appPanel").hidden = true; $("authPanel").hidden = false; }

$("loginTab").addEventListener("click", () => setMode("login"));
$("signupTab").addEventListener("click", () => setMode("signup"));

$("authForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!client) return message("authMessage", "First add your Supabase URL and anon key in app.js.", true);
  const email = $("email").value.trim(), password = $("password").value;
  $("authSubmit").disabled = true;
  try {
    if (authMode === "signup") {
      const { data, error } = await client.auth.signUp({ email, password });
      if (error) throw error;
      message("authMessage", data.session ? "Account created. You are signed in." : "Account created. Check your email to confirm, then log in.");
      if (data.session) showApp(data.user);
    } else {
      const { data, error } = await client.auth.signInWithPassword({ email, password });
      if (error) throw error;
      showApp(data.user);
    }
  } catch (e) { message("authMessage", e.message, true); }
  finally { $("authSubmit").disabled = false; }
});

$("forgotBtn").addEventListener("click", async () => {
  if (!client) return message("authMessage", "Configure Supabase first.", true);
  const email = $("email").value.trim();
  if (!email) return message("authMessage", "Enter your email address first.", true);
  const { error } = await client.auth.resetPasswordForEmail(email);
  message("authMessage", error ? error.message : "If the account exists, a password reset email will arrive.");
});

$("logoutBtn").addEventListener("click", async () => {
  if (client) await client.auth.signOut();
  showAuth();
});
$("fileInput").addEventListener("change", () => {
  currentFile = $("fileInput").files[0] || null;
  $("selectedFile").textContent = currentFile ? `${currentFile.name} · ${formatSize(currentFile.size)}` : "No file selected";
  $("uploadBtn").disabled = !currentFile;
});
$("uploadBtn").addEventListener("click", uploadFile);
$("refreshBtn").addEventListener("click", loadFiles);

function formatSize(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024*1024) return (bytes/1024).toFixed(1) + " KB";
  return (bytes/1024/1024).toFixed(1) + " MB";
}
function safeName(name) { return name.replace(/[^\w.\-() ]/g, "_").slice(0, 120) || "file"; }
function fileEmoji(name) {
  const ext = name.split(".").pop().toLowerCase();
  if (ext === "pdf") return "📕";
  if (["png","jpg","jpeg","gif","webp"].includes(ext)) return "🖼️";
  if (["doc","docx"].includes(ext)) return "📝";
  if (["xls","xlsx","csv"].includes(ext)) return "📊";
  if (["mp4","mov","webm"].includes(ext)) return "🎬";
  if (["zip","rar","7z"].includes(ext)) return "🗜️";
  return "📄";
}

async function uploadFile() {
  if (!client || !currentFile) return;
  if (currentFile.size > MAX_FILE_SIZE) return message("uploadMessage", "File is larger than 50 MB. Increase the limit only after checking your storage plan.", true);
  const { data: { user }, error: userError } = await client.auth.getUser();
  if (userError || !user) return message("uploadMessage", "Please log in again.", true);
  $("uploadBtn").disabled = true;
  message("uploadMessage", "Uploading…");
  const objectPath = `${user.id}/${crypto.randomUUID()}-${safeName(currentFile.name)}`;
  try {
    const { error: uploadError } = await client.storage.from(BUCKET).upload(objectPath, currentFile, {
      cacheControl: "3600", upsert: false, contentType: currentFile.type || "application/octet-stream"
    });
    if (uploadError) throw uploadError;
    const { error: dbError } = await client.from("documents").insert({
      owner_id: user.id, storage_path: objectPath, file_name: currentFile.name,
      mime_type: currentFile.type || "application/octet-stream", size_bytes: currentFile.size
    });
    if (dbError) {
      await client.storage.from(BUCKET).remove([objectPath]);
      throw dbError;
    }
    message("uploadMessage", "Upload complete.");
    $("fileInput").value = ""; currentFile = null; $("selectedFile").textContent = "No file selected";
    await loadFiles();
  } catch (e) { message("uploadMessage", e.message, true); }
  finally { $("uploadBtn").disabled = !currentFile; }
}

async function loadFiles() {
  if (!client) {
    $("fileList").innerHTML = '<div class="empty">Set up Supabase first. Follow README-BN.txt.</div>';
    return;
  }
  $("fileList").innerHTML = '<div class="empty">Loading…</div>';
  const { data, error } = await client.from("documents").select("id,file_name,mime_type,size_bytes,created_at,storage_path").order("created_at", { ascending: false });
  if (error) { $("fileList").innerHTML = `<div class="empty">${escapeHtml(error.message)}</div>`; return; }
  if (!data.length) { $("fileList").innerHTML = '<div class="empty">No documents yet. Upload your first file.</div>'; return; }
  $("fileList").replaceChildren(...data.map(doc => {
    const card = document.createElement("article"); card.className = "file-card";
    const icon = document.createElement("div"); icon.className = "file-icon"; icon.textContent = fileEmoji(doc.file_name);
    const info = document.createElement("div"); info.className = "file-info";
    const name = document.createElement("div"); name.className = "file-name"; name.textContent = doc.file_name;
    const meta = document.createElement("div"); meta.className = "file-meta";
    meta.textContent = `${formatSize(doc.size_bytes)} · ${new Date(doc.created_at).toLocaleString()}`;
    info.append(name, meta);
    const actions = document.createElement("div"); actions.className = "file-actions";
    const dl = document.createElement("button"); dl.className = "download"; dl.textContent = "Download";
    dl.addEventListener("click", () => downloadFile(doc));
    const del = document.createElement("button"); del.className = "delete"; del.textContent = "Delete";
    del.addEventListener("click", () => deleteFile(doc));
    actions.append(dl, del); card.append(icon, info, actions); return card;
  }));
}
async function downloadFile(doc) {
  const { data, error } = await client.storage.from(BUCKET).createSignedUrl(doc.storage_path, 60);
  if (error) return alert(error.message);
  const a = document.createElement("a"); a.href = data.signedUrl; a.download = doc.file_name;
  document.body.appendChild(a); a.click(); a.remove();
}
async function deleteFile(doc) {
  if (!confirm(`Delete "${doc.file_name}" permanently?`)) return;
  const { error: storageError } = await client.storage.from(BUCKET).remove([doc.storage_path]);
  if (storageError) return alert(storageError.message);
  const { error: dbError } = await client.from("documents").delete().eq("id", doc.id);
  if (dbError) return alert(dbError.message);
  loadFiles();
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}

(async function init() {
  if (!client) {
    message("authMessage", "Setup needed: add Supabase URL and anon key in app.js.", true);
    return;
  }
  const { data: { session } } = await client.auth.getSession();
  if (session?.user) showApp(session.user);
  client.auth.onAuthStateChange((_event, sessionNow) => {
    if (sessionNow?.user) showApp(sessionNow.user);
    else showAuth();
  });
})();
